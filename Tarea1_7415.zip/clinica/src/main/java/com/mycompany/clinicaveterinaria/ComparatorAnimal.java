package com.mycompany.clinicaveterinaria;

import java.util.Comparator;

public class ComparatorAnimal {

    // Comparador por nombre (A-Z)
    public static class ComparadoPorNombre implements Comparator<Animal> {
        @Override
        public int compare(Animal a1, Animal a2) {
            return a1.getNombre().compareTo(a2.getNombre());
        }
    }

    // Comparador por edad ascendente
    public static class ComparadoPorEdad implements Comparator<Animal> {
        @Override
        public int compare(Animal a1, Animal a2) {
            return Integer.compare(a1.getEdadAnios(), a2.getEdadAnios());
        }
    }

    // Comparador por peso descendente (mayor peso primero)
    public static class ComparadoPorPesoDesc implements Comparator<Animal> {
        @Override
        public int compare(Animal a1, Animal a2) {
            return Double.compare(a2.getPesoKg(), a1.getPesoKg());
        }
    }

    // Comparador por fecha de ingreso (mas reciente primero)
    public static class ComparadoPorFechaIngreso implements Comparator<Animal> {
        @Override
        public int compare(Animal a1, Animal a2) {
            return a2.getFechaIngreso().compareTo(a1.getFechaIngreso());
        }
    }
}
