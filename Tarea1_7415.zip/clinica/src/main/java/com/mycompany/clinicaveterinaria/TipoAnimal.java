package com.mycompany.clinicaveterinaria;

public enum TipoAnimal {
    Perro,
    Gato,
    Loro,
    Hamster,
    Tortuga
}
