package com.mycompany.clinicaveterinaria;

import java.sql.Date;

public class Vacuna {
    private String nombre;
    private String laboratorio;
    private Date fechaAplicacion;
    private Date fechaProximaDosis;

    public Vacuna() {
    }

    public Vacuna(String nombre, String laboratorio, Date fechaAplicacion, Date fechaProximaDosis) {
        this.nombre = nombre;
        this.laboratorio = laboratorio;
        this.fechaAplicacion = fechaAplicacion;
        this.fechaProximaDosis = fechaProximaDosis;
    }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getLaboratorio() { return laboratorio; }
    public void setLaboratorio(String laboratorio) { this.laboratorio = laboratorio; }

    public Date getFechaAplicacion() { return fechaAplicacion; }
    public void setFechaAplicacion(Date fechaAplicacion) { this.fechaAplicacion = fechaAplicacion; }

    public Date getFechaProximaDosis() { return fechaProximaDosis; }
    public void setFechaProximaDosis(Date fechaProximaDosis) { this.fechaProximaDosis = fechaProximaDosis; }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Vacuna{");
        sb.append("nombre=").append(nombre);
        sb.append(", laboratorio=").append(laboratorio);
        sb.append(", fechaAplicacion=").append(fechaAplicacion);
        sb.append(", fechaProximaDosis=").append(fechaProximaDosis);
        sb.append('}');
        return sb.toString();
    }
}
