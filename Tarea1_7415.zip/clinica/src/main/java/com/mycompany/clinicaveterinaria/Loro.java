package com.mycompany.clinicaveterinaria;

import java.sql.Date;

public class Loro extends Animal {
    private String especie;
    private String colorPlumaje;
    private boolean habla;

    public Loro() {
    }

    public Loro(String especie, String colorPlumaje, boolean habla,
                int idExpediente, String nombre, int edadAnios, double pesoKg,
                String propietario, String telefonoPropietario, Date fechaIngreso, String observaciones) {
        super(idExpediente, nombre, edadAnios, pesoKg, propietario, telefonoPropietario, fechaIngreso, observaciones);
        this.especie = especie;
        this.colorPlumaje = colorPlumaje;
        this.habla = habla;
    }

    public String getEspecie() { return especie; }
    public void setEspecie(String especie) { this.especie = especie; }

    public String getColorPlumaje() { return colorPlumaje; }
    public void setColorPlumaje(String colorPlumaje) { this.colorPlumaje = colorPlumaje; }

    public boolean isHabla() { return habla; }
    public void setHabla(boolean habla) { this.habla = habla; }

    @Override
    public String obtenerInfoEspecie() {
        StringBuilder sb = new StringBuilder();
        sb.append("[LORO] ");
        sb.append("Especie: ").append(especie);
        sb.append(" | Color plumaje: ").append(colorPlumaje);
        sb.append(" | Habla: ").append(habla ? "Si" : "No");
        return sb.toString();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append(" Loro{");
        sb.append("especie=").append(especie);
        sb.append(", colorPlumaje=").append(colorPlumaje);
        sb.append(", habla=").append(habla);
        sb.append('}');
        return sb.toString();
    }
}
