package com.mycompany.clinicaveterinaria;

import java.sql.Date;

public class Perro extends Animal {
    private String raza;
    private boolean esterilizado;
    private String colorPelaje;

    public Perro() {
    }

    public Perro(String raza, boolean esterilizado, String colorPelaje,
                 int idExpediente, String nombre, int edadAnios, double pesoKg,
                 String propietario, String telefonoPropietario, Date fechaIngreso, String observaciones) {
        super(idExpediente, nombre, edadAnios, pesoKg, propietario, telefonoPropietario, fechaIngreso, observaciones);
        this.raza = raza;
        this.esterilizado = esterilizado;
        this.colorPelaje = colorPelaje;
    }

    public String getRaza() { return raza; }
    public void setRaza(String raza) { this.raza = raza; }

    public boolean isEsterilizado() { return esterilizado; }
    public void setEsterilizado(boolean esterilizado) { this.esterilizado = esterilizado; }

    public String getColorPelaje() { return colorPelaje; }
    public void setColorPelaje(String colorPelaje) { this.colorPelaje = colorPelaje; }

    @Override
    public String obtenerInfoEspecie() {
        StringBuilder sb = new StringBuilder();
        sb.append("[PERRO] ");
        sb.append("Raza: ").append(raza);
        sb.append(" | Color pelaje: ").append(colorPelaje);
        sb.append(" | Esterilizado: ").append(esterilizado ? "Si" : "No");
        return sb.toString();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append(" Perro{");
        sb.append("raza=").append(raza);
        sb.append(", esterilizado=").append(esterilizado);
        sb.append(", colorPelaje=").append(colorPelaje);
        sb.append('}');
        return sb.toString();
    }
}
