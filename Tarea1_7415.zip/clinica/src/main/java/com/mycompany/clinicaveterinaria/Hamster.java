package com.mycompany.clinicaveterinaria;

import java.sql.Date;

public class Hamster extends Animal {
    private String colorPelaje;
    private boolean tieneCajaRueda;

    public Hamster() {
    }

    public Hamster(String colorPelaje, boolean tieneCajaRueda,
                   int idExpediente, String nombre, int edadAnios, double pesoKg,
                   String propietario, String telefonoPropietario, Date fechaIngreso, String observaciones) {
        super(idExpediente, nombre, edadAnios, pesoKg, propietario, telefonoPropietario, fechaIngreso, observaciones);
        this.colorPelaje = colorPelaje;
        this.tieneCajaRueda = tieneCajaRueda;
    }

    public String getColorPelaje() { return colorPelaje; }
    public void setColorPelaje(String colorPelaje) { this.colorPelaje = colorPelaje; }

    public boolean isTieneCajaRueda() { return tieneCajaRueda; }
    public void setTieneCajaRueda(boolean tieneCajaRueda) { this.tieneCajaRueda = tieneCajaRueda; }

    @Override
    public String obtenerInfoEspecie() {
        StringBuilder sb = new StringBuilder();
        sb.append("[HAMSTER] ");
        sb.append("Color pelaje: ").append(colorPelaje);
        sb.append(" | Tiene caja con rueda: ").append(tieneCajaRueda ? "Si" : "No");
        return sb.toString();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append(" Hamster{");
        sb.append("colorPelaje=").append(colorPelaje);
        sb.append(", tieneCajaRueda=").append(tieneCajaRueda);
        sb.append('}');
        return sb.toString();
    }
}
