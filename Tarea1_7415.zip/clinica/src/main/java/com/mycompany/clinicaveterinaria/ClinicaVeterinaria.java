package com.mycompany.clinicaveterinaria;

import java.sql.Date;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class ClinicaVeterinaria {

    private static List<Animal> expedientes = new ArrayList<>();
    private static Scanner sc = new Scanner(System.in);
    private static int contadorId = 1;

    public static void main(String[] args) {
        int opcion = 0;
        do {
            mostrarMenu();
            try {
                opcion = Integer.parseInt(sc.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("  [!] Ingrese un numero valido.");
                continue;
            }

            switch (opcion) {
                case 1: registrarAnimal();      break;
                case 2: consultarExpediente();  break;
                case 3: registrarVacuna();      break;
                case 4: registrarMedicamento(); break;
                case 5: mostrarTodosAnimales(); break;
                case 6: buscarAnimal();         break;
                case 7: ordenarAnimales();      break;
                case 8: System.out.println("\n  Hasta luego. Sistema cerrado."); break;
                default: System.out.println("  [!] Opcion no valida. Intente de nuevo.");
            }
        } while (opcion != 8);
    }

    // -------------------------------------------------------------------------
    // MENU
    // -------------------------------------------------------------------------
    private static void mostrarMenu() {
        System.out.println("\n========================================");
        System.out.println("   Clinica Veterinaria - Mascotas Felices");
        System.out.println("========================================");
        System.out.println("  1. Registrar animal");
        System.out.println("  2. Consultar expediente");
        System.out.println("  3. Registrar vacuna");
        System.out.println("  4. Registrar medicamento");
        System.out.println("  5. Mostrar todos los animales");
        System.out.println("  6. Buscar animal");
        System.out.println("  7. Ordenar animales");
        System.out.println("  8. Salir");
        System.out.print("  Seleccione una opcion: ");
    }

    // -------------------------------------------------------------------------
    // 1. REGISTRAR ANIMAL
    // -------------------------------------------------------------------------
    private static void registrarAnimal() {
        System.out.println("\n--- Registrar Animal ---");
        System.out.println("  Tipo de animal:");
        System.out.println("  1. Perro  2. Gato  3. Loro  4. Hamster  5. Tortuga");
        System.out.print("  Seleccione: ");

        int tipo = 0;
        try {
            tipo = Integer.parseInt(sc.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("  [!] Tipo invalido.");
            return;
        }

        if (tipo < 1 || tipo > 5) {
            System.out.println("  [!] Opcion de tipo no valida.");
            return;
        }

        // Datos comunes (igual que los datos de Persona en el zip)
        System.out.print("  Nombre del animal: ");
        String nombre = sc.nextLine().trim();

        int edad = 0;
        try {
            System.out.print("  Edad (anios): ");
            edad = Integer.parseInt(sc.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("  [!] Edad invalida, se asigna 0.");
        }

        double peso = 0.0;
        try {
            System.out.print("  Peso (kg): ");
            peso = Double.parseDouble(sc.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("  [!] Peso invalido, se asigna 0.0.");
        }

        System.out.print("  Nombre del propietario: ");
        String propietario = sc.nextLine().trim();

        System.out.print("  Telefono del propietario: ");
        String telefono = sc.nextLine().trim();

        Date fechaIngreso = Date.valueOf("0001-01-01");
        try {
            System.out.print("  Fecha de ingreso (YYYY-MM-DD): ");
            fechaIngreso = Date.valueOf(sc.nextLine().trim());
        } catch (IllegalArgumentException e) {
            System.out.println("  [!] Formato de fecha invalido. Se usara 0001-01-01.");
        }

        System.out.print("  Observaciones medicas: ");
        String observaciones = sc.nextLine().trim();

        int id = contadorId++;
        Animal animal = null;

        // Datos especificos por especie
        switch (tipo) {
            case 1: {
                System.out.print("  Raza: ");
                String raza = sc.nextLine().trim();
                System.out.print("  Color de pelaje: ");
                String color = sc.nextLine().trim();
                System.out.print("  Esterilizado? (s/n): ");
                boolean esterilizado = sc.nextLine().trim().equalsIgnoreCase("s");
                animal = new Perro(raza, esterilizado, color, id, nombre, edad, peso, propietario, telefono, fechaIngreso, observaciones);
                break;
            }
            case 2: {
                System.out.print("  Raza: ");
                String raza = sc.nextLine().trim();
                System.out.print("  Esterilizado? (s/n): ");
                boolean esterilizado = sc.nextLine().trim().equalsIgnoreCase("s");
                System.out.print("  Usa arenero? (s/n): ");
                boolean arenero = sc.nextLine().trim().equalsIgnoreCase("s");
                animal = new Gato(raza, esterilizado, arenero, id, nombre, edad, peso, propietario, telefono, fechaIngreso, observaciones);
                break;
            }
            case 3: {
                System.out.print("  Especie de loro: ");
                String especie = sc.nextLine().trim();
                System.out.print("  Color de plumaje: ");
                String color = sc.nextLine().trim();
                System.out.print("  Habla? (s/n): ");
                boolean habla = sc.nextLine().trim().equalsIgnoreCase("s");
                animal = new Loro(especie, color, habla, id, nombre, edad, peso, propietario, telefono, fechaIngreso, observaciones);
                break;
            }
            case 4: {
                System.out.print("  Color de pelaje: ");
                String color = sc.nextLine().trim();
                System.out.print("  Tiene caja con rueda? (s/n): ");
                boolean rueda = sc.nextLine().trim().equalsIgnoreCase("s");
                animal = new Hamster(color, rueda, id, nombre, edad, peso, propietario, telefono, fechaIngreso, observaciones);
                break;
            }
            case 5: {
                System.out.print("  Tipo (acuatica/terrestre): ");
                String tipoTort = sc.nextLine().trim();
                double largo = 0.0;
                try {
                    System.out.print("  Largo del caparazon (cm): ");
                    largo = Double.parseDouble(sc.nextLine().trim());
                } catch (NumberFormatException e) {
                    System.out.println("  [!] Valor invalido, se asigna 0.0.");
                }
                animal = new Tortuga(tipoTort, largo, id, nombre, edad, peso, propietario, telefono, fechaIngreso, observaciones);
                break;
            }
        }

        expedientes.add(animal);
        System.out.println("\n  [OK] Animal registrado correctamente. Expediente #" + id);
    }

    // -------------------------------------------------------------------------
    // 2. CONSULTAR EXPEDIENTE
    // -------------------------------------------------------------------------
    private static void consultarExpediente() {
        System.out.println("\n--- Consultar Expediente ---");
        if (expedientes.isEmpty()) {
            System.out.println("  No hay animales registrados.");
            return;
        }

        System.out.print("  Ingrese el ID del expediente: ");
        int id = 0;
        try {
            id = Integer.parseInt(sc.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("  [!] ID invalido.");
            return;
        }

        Animal encontrado = buscarPorId(id);
        if (encontrado == null) {
            System.out.println("  [!] No se encontro un expediente con ID " + id);
            return;
        }

        imprimirExpedienteCompleto(encontrado);
    }

    // -------------------------------------------------------------------------
    // 3. REGISTRAR VACUNA
    // -------------------------------------------------------------------------
    private static void registrarVacuna() {
        System.out.println("\n--- Registrar Vacuna ---");
        if (expedientes.isEmpty()) {
            System.out.println("  No hay animales registrados.");
            return;
        }

        System.out.print("  ID del expediente al que desea agregar la vacuna: ");
        int id = 0;
        try {
            id = Integer.parseInt(sc.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("  [!] ID invalido.");
            return;
        }

        Animal animal = buscarPorId(id);
        if (animal == null) {
            System.out.println("  [!] No se encontro un expediente con ID " + id);
            return;
        }

        System.out.print("  Nombre de la vacuna: ");
        String nombre = sc.nextLine().trim();

        System.out.print("  Laboratorio: ");
        String laboratorio = sc.nextLine().trim();

        Date fechaAplicacion = Date.valueOf("0001-01-01");
        try {
            System.out.print("  Fecha de aplicacion (YYYY-MM-DD): ");
            fechaAplicacion = Date.valueOf(sc.nextLine().trim());
        } catch (IllegalArgumentException e) {
            System.out.println("  [!] Formato invalido. Se usara 0001-01-01.");
        }

        Date fechaProxima = Date.valueOf("0001-01-01");
        try {
            System.out.print("  Fecha proxima dosis (YYYY-MM-DD): ");
            fechaProxima = Date.valueOf(sc.nextLine().trim());
        } catch (IllegalArgumentException e) {
            System.out.println("  [!] Formato invalido. Se usara 0001-01-01.");
        }

        Vacuna v = new Vacuna(nombre, laboratorio, fechaAplicacion, fechaProxima);
        animal.agregarVacuna(v);
        System.out.println("  [OK] Vacuna agregada al expediente de " + animal.getNombre());
    }

    // -------------------------------------------------------------------------
    // 4. REGISTRAR MEDICAMENTO
    // -------------------------------------------------------------------------
    private static void registrarMedicamento() {
        System.out.println("\n--- Registrar Medicamento ---");
        if (expedientes.isEmpty()) {
            System.out.println("  No hay animales registrados.");
            return;
        }

        System.out.print("  ID del expediente: ");
        int id = 0;
        try {
            id = Integer.parseInt(sc.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("  [!] ID invalido.");
            return;
        }

        Animal animal = buscarPorId(id);
        if (animal == null) {
            System.out.println("  [!] No se encontro un expediente con ID " + id);
            return;
        }

        System.out.print("  Nombre del medicamento: ");
        String nombre = sc.nextLine().trim();

        System.out.print("  Dosis (ej: 5mg cada 8 horas): ");
        String dosis = sc.nextLine().trim();

        int duracion = 0;
        try {
            System.out.print("  Duracion en dias: ");
            duracion = Integer.parseInt(sc.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("  [!] Valor invalido, se asigna 0.");
        }

        Date fechaReceta = Date.valueOf("0001-01-01");
        try {
            System.out.print("  Fecha de receta (YYYY-MM-DD): ");
            fechaReceta = Date.valueOf(sc.nextLine().trim());
        } catch (IllegalArgumentException e) {
            System.out.println("  [!] Formato invalido. Se usara 0001-01-01.");
        }

        Medicamento m = new Medicamento(nombre, dosis, duracion, fechaReceta);
        animal.agregarMedicamento(m);
        System.out.println("  [OK] Medicamento agregado al expediente de " + animal.getNombre());
    }

    // -------------------------------------------------------------------------
    // 5. MOSTRAR TODOS LOS ANIMALES
    // -------------------------------------------------------------------------
    private static void mostrarTodosAnimales() {
        System.out.println("\n--- Listado de Animales Registrados ---");
        if (expedientes.isEmpty()) {
            System.out.println("  No hay animales registrados.");
            return;
        }

        System.out.println("  Total: " + expedientes.size() + " expediente(s)\n");
        for (Animal a : expedientes) {
            imprimirResumenAnimal(a);
        }
    }

    // -------------------------------------------------------------------------
    // 6. BUSCAR ANIMAL
    // -------------------------------------------------------------------------
    private static void buscarAnimal() {
        System.out.println("\n--- Buscar Animal ---");
        if (expedientes.isEmpty()) {
            System.out.println("  No hay animales registrados.");
            return;
        }

        System.out.println("  Criterio de busqueda:");
        System.out.println("  1. Por nombre del animal");
        System.out.println("  2. Por nombre del propietario");
        System.out.print("  Seleccione: ");

        int criterio = 0;
        try {
            criterio = Integer.parseInt(sc.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("  [!] Opcion invalida.");
            return;
        }

        System.out.print("  Ingrese el texto a buscar: ");
        String texto = sc.nextLine().trim().toLowerCase();

        List<Animal> resultados = new ArrayList<>();
        for (Animal a : expedientes) {
            if (criterio == 1 && a.getNombre().toLowerCase().contains(texto)) {
                resultados.add(a);
            } else if (criterio == 2 && a.getPropietario().toLowerCase().contains(texto)) {
                resultados.add(a);
            }
        }

        if (resultados.isEmpty()) {
            System.out.println("  No se encontraron resultados.");
        } else {
            System.out.println("  Resultados encontrados: " + resultados.size());
            for (Animal a : resultados) {
                imprimirResumenAnimal(a);
            }
        }
    }

    // -------------------------------------------------------------------------
    // 7. ORDENAR ANIMALES
    // -------------------------------------------------------------------------
    private static void ordenarAnimales() {
        System.out.println("\n--- Ordenar Animales ---");
        if (expedientes.isEmpty()) {
            System.out.println("  No hay animales registrados.");
            return;
        }

        System.out.println("  Criterio de ordenamiento:");
        System.out.println("  1. Por ID de expediente (Comparable - natural)");
        System.out.println("  2. Por nombre A-Z (Comparator)");
        System.out.println("  3. Por edad ascendente (Comparator)");
        System.out.println("  4. Por peso descendente (Comparator)");
        System.out.println("  5. Por fecha de ingreso mas reciente (Comparator)");
        System.out.print("  Seleccione: ");

        int criterio = 0;
        try {
            criterio = Integer.parseInt(sc.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("  [!] Opcion invalida.");
            return;
        }

        switch (criterio) {
            case 1:
                expedientes.sort(null); // usa Comparable de Animal
                System.out.println("  [OK] Ordenado por ID de expediente.");
                break;
            case 2:
                expedientes.sort(new ComparatorAnimal.ComparadoPorNombre());
                System.out.println("  [OK] Ordenado por nombre A-Z.");
                break;
            case 3:
                expedientes.sort(new ComparatorAnimal.ComparadoPorEdad());
                System.out.println("  [OK] Ordenado por edad ascendente.");
                break;
            case 4:
                expedientes.sort(new ComparatorAnimal.ComparadoPorPesoDesc());
                System.out.println("  [OK] Ordenado por peso descendente.");
                break;
            case 5:
                expedientes.sort(new ComparatorAnimal.ComparadoPorFechaIngreso());
                System.out.println("  [OK] Ordenado por fecha de ingreso mas reciente.");
                break;
            default:
                System.out.println("  [!] Opcion no valida.");
                return;
        }

        mostrarTodosAnimales();
    }

    // -------------------------------------------------------------------------
    // UTILIDADES INTERNAS
    // -------------------------------------------------------------------------
    private static Animal buscarPorId(int id) {
        for (Animal a : expedientes) {
            if (a.getIdExpediente() == id) {
                return a;
            }
        }
        return null;
    }

    private static void imprimirResumenAnimal(Animal a) {
        System.out.println("  ----------------------------------------");
        System.out.println("  Expediente #" + a.getIdExpediente() + " | " + a.obtenerInfoEspecie());
        System.out.println("  Nombre: " + a.getNombre() + " | Edad: " + a.getEdadAnios() + " anios | Peso: " + a.getPesoKg() + " kg");
        System.out.println("  Propietario: " + a.getPropietario() + " | Tel: " + a.getTelefonoPropietario());
        System.out.println("  Ingreso: " + a.getFechaIngreso());
        System.out.println("  Vacunas: " + a.getVacunas().size() + " | Medicamentos: " + a.getMedicamentos().size());
    }

    private static void imprimirExpedienteCompleto(Animal a) {
        System.out.println("\n  ========================================");
        System.out.println("  EXPEDIENTE #" + a.getIdExpediente());
        System.out.println("  " + a.obtenerInfoEspecie());
        System.out.println("  ----------------------------------------");
        System.out.println("  Nombre:       " + a.getNombre());
        System.out.println("  Edad:         " + a.getEdadAnios() + " anios");
        System.out.println("  Peso:         " + a.getPesoKg() + " kg");
        System.out.println("  Propietario:  " + a.getPropietario());
        System.out.println("  Telefono:     " + a.getTelefonoPropietario());
        System.out.println("  Fecha ingreso:" + a.getFechaIngreso());
        System.out.println("  Observaciones:" + a.getObservaciones());

        System.out.println("  --- Vacunas (" + a.getVacunas().size() + ") ---");
        if (a.getVacunas().isEmpty()) {
            System.out.println("  Sin vacunas registradas.");
        } else {
            for (Vacuna v : a.getVacunas()) {
                System.out.println("  * " + v.getNombre() + " | Lab: " + v.getLaboratorio()
                        + " | Aplicada: " + v.getFechaAplicacion()
                        + " | Proxima: " + v.getFechaProximaDosis());
            }
        }

        System.out.println("  --- Medicamentos (" + a.getMedicamentos().size() + ") ---");
        if (a.getMedicamentos().isEmpty()) {
            System.out.println("  Sin medicamentos registrados.");
        } else {
            for (Medicamento m : a.getMedicamentos()) {
                System.out.println("  * " + m.getNombre() + " | Dosis: " + m.getDosis()
                        + " | Duracion: " + m.getDuracionDias() + " dias"
                        + " | Receta: " + m.getFechaReceta());
            }
        }
        System.out.println("  ========================================");
    }
}
