package com.mycompany.clinicaveterinaria;

import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

public abstract class Animal implements Comparable<Animal> {
    private int idExpediente;
    private String nombre;
    private int edadAnios;
    private double pesoKg;
    private String propietario;
    private String telefonoPropietario;
    private Date fechaIngreso;
    private String observaciones;
    private List<Vacuna> vacunas;
    private List<Medicamento> medicamentos;

    public Animal() {
        this.vacunas = new ArrayList<>();
        this.medicamentos = new ArrayList<>();
    }

    public Animal(int idExpediente, String nombre, int edadAnios, double pesoKg,
                  String propietario, String telefonoPropietario, Date fechaIngreso, String observaciones) {
        this.idExpediente = idExpediente;
        this.nombre = nombre;
        this.edadAnios = edadAnios;
        this.pesoKg = pesoKg;
        this.propietario = propietario;
        this.telefonoPropietario = telefonoPropietario;
        this.fechaIngreso = fechaIngreso;
        this.observaciones = observaciones;
        this.vacunas = new ArrayList<>();
        this.medicamentos = new ArrayList<>();
    }

    public int getIdExpediente() { return idExpediente; }
    public void setIdExpediente(int idExpediente) { this.idExpediente = idExpediente; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public int getEdadAnios() { return edadAnios; }
    public void setEdadAnios(int edadAnios) { this.edadAnios = edadAnios; }

    public double getPesoKg() { return pesoKg; }
    public void setPesoKg(double pesoKg) { this.pesoKg = pesoKg; }

    public String getPropietario() { return propietario; }
    public void setPropietario(String propietario) { this.propietario = propietario; }

    public String getTelefonoPropietario() { return telefonoPropietario; }
    public void setTelefonoPropietario(String telefonoPropietario) { this.telefonoPropietario = telefonoPropietario; }

    public Date getFechaIngreso() { return fechaIngreso; }
    public void setFechaIngreso(Date fechaIngreso) { this.fechaIngreso = fechaIngreso; }

    public String getObservaciones() { return observaciones; }
    public void setObservaciones(String observaciones) { this.observaciones = observaciones; }

    public List<Vacuna> getVacunas() { return vacunas; }
    public void setVacunas(List<Vacuna> vacunas) { this.vacunas = vacunas; }

    public List<Medicamento> getMedicamentos() { return medicamentos; }
    public void setMedicamentos(List<Medicamento> medicamentos) { this.medicamentos = medicamentos; }

    public void agregarVacuna(Vacuna v) { this.vacunas.add(v); }
    public void agregarMedicamento(Medicamento m) { this.medicamentos.add(m); }

    // Comparable: ordenamiento natural por idExpediente (igual que Cliente ordena por numeroCliente)
    @Override
    public int compareTo(Animal otroAnimal) {
        return Integer.compare(this.idExpediente, otroAnimal.idExpediente);
    }

    // Metodo abstracto: cada especie muestra su informacion especifica
    public abstract String obtenerInfoEspecie();

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Animal{");
        sb.append("idExpediente=").append(idExpediente);
        sb.append(", nombre=").append(nombre);
        sb.append(", edadAnios=").append(edadAnios);
        sb.append(", pesoKg=").append(pesoKg);
        sb.append(", propietario=").append(propietario);
        sb.append(", telefonoPropietario=").append(telefonoPropietario);
        sb.append(", fechaIngreso=").append(fechaIngreso);
        sb.append(", observaciones=").append(observaciones);
        sb.append('}');
        return sb.toString();
    }
}
