package com.mycompany.clinicaveterinaria;

import java.sql.Date;

public class Gato extends Animal {
    private String raza;
    private boolean esterilizado;
    private boolean usaArenero;

    public Gato() {
    }

    public Gato(String raza, boolean esterilizado, boolean usaArenero,
                int idExpediente, String nombre, int edadAnios, double pesoKg,
                String propietario, String telefonoPropietario, Date fechaIngreso, String observaciones) {
        super(idExpediente, nombre, edadAnios, pesoKg, propietario, telefonoPropietario, fechaIngreso, observaciones);
        this.raza = raza;
        this.esterilizado = esterilizado;
        this.usaArenero = usaArenero;
    }

    public String getRaza() { return raza; }
    public void setRaza(String raza) { this.raza = raza; }

    public boolean isEsterilizado() { return esterilizado; }
    public void setEsterilizado(boolean esterilizado) { this.esterilizado = esterilizado; }

    public boolean isUsaArenero() { return usaArenero; }
    public void setUsaArenero(boolean usaArenero) { this.usaArenero = usaArenero; }

    @Override
    public String obtenerInfoEspecie() {
        StringBuilder sb = new StringBuilder();
        sb.append("[GATO] ");
        sb.append("Raza: ").append(raza);
        sb.append(" | Esterilizado: ").append(esterilizado ? "Si" : "No");
        sb.append(" | Usa arenero: ").append(usaArenero ? "Si" : "No");
        return sb.toString();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append(" Gato{");
        sb.append("raza=").append(raza);
        sb.append(", esterilizado=").append(esterilizado);
        sb.append(", usaArenero=").append(usaArenero);
        sb.append('}');
        return sb.toString();
    }
}
