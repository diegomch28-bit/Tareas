package com.mycompany.clinicaveterinaria;

import java.sql.Date;

public class Medicamento {
    private String nombre;
    private String dosis;
    private int duracionDias;
    private Date fechaReceta;

    public Medicamento() {
    }

    public Medicamento(String nombre, String dosis, int duracionDias, Date fechaReceta) {
        this.nombre = nombre;
        this.dosis = dosis;
        this.duracionDias = duracionDias;
        this.fechaReceta = fechaReceta;
    }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getDosis() { return dosis; }
    public void setDosis(String dosis) { this.dosis = dosis; }

    public int getDuracionDias() { return duracionDias; }
    public void setDuracionDias(int duracionDias) { this.duracionDias = duracionDias; }

    public Date getFechaReceta() { return fechaReceta; }
    public void setFechaReceta(Date fechaReceta) { this.fechaReceta = fechaReceta; }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Medicamento{");
        sb.append("nombre=").append(nombre);
        sb.append(", dosis=").append(dosis);
        sb.append(", duracionDias=").append(duracionDias);
        sb.append(", fechaReceta=").append(fechaReceta);
        sb.append('}');
        return sb.toString();
    }
}
