package com.mycompany.clinicaveterinaria;

import java.sql.Date;

public class Tortuga extends Animal {
    private String tipoTortuga; // acuatica / terrestre
    private double largoCaparazonCm;

    public Tortuga() {
    }

    public Tortuga(String tipoTortuga, double largoCaparazonCm,
                   int idExpediente, String nombre, int edadAnios, double pesoKg,
                   String propietario, String telefonoPropietario, Date fechaIngreso, String observaciones) {
        super(idExpediente, nombre, edadAnios, pesoKg, propietario, telefonoPropietario, fechaIngreso, observaciones);
        this.tipoTortuga = tipoTortuga;
        this.largoCaparazonCm = largoCaparazonCm;
    }

    public String getTipoTortuga() { return tipoTortuga; }
    public void setTipoTortuga(String tipoTortuga) { this.tipoTortuga = tipoTortuga; }

    public double getLargoCaparazonCm() { return largoCaparazonCm; }
    public void setLargoCaparazonCm(double largoCaparazonCm) { this.largoCaparazonCm = largoCaparazonCm; }

    @Override
    public String obtenerInfoEspecie() {
        StringBuilder sb = new StringBuilder();
        sb.append("[TORTUGA] ");
        sb.append("Tipo: ").append(tipoTortuga);
        sb.append(" | Largo caparazon: ").append(largoCaparazonCm).append(" cm");
        return sb.toString();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString());
        sb.append(" Tortuga{");
        sb.append("tipoTortuga=").append(tipoTortuga);
        sb.append(", largoCaparazonCm=").append(largoCaparazonCm);
        sb.append('}');
        return sb.toString();
    }
}
